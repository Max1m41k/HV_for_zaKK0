replacements = {
    'music/menu/menu1': 'music/menu/mutation',
    'music/menu/menu2': 'music/menu/moog_city_2',
    'music/menu/menu3': 'music/menu/beginning_2',
    'music/menu/menu4': 'music/menu/floating_trees',
    'music/game/calm1': 'music/game/minecraft',
    'music/game/calm2': 'music/game/clark',
    'music/game/calm3': 'music/game/sweden',
    'music/game/hal1': 'music/game/subwoofer_lullaby',
    'music/game/hal2': 'music/game/living_mice',
    'music/game/hal3': 'music/game/haggstrom',
    'music/game/hal4': 'music/game/danny',
    'music/game/nuance1': 'music/game/key',
    'music/game/nuance2': 'music/game/oxygene',
    'music/game/piano1': 'music/game/dry_hands',
    'music/game/piano2': 'music/game/wet_hands',
    'music/game/piano3': 'music/game/mice_on_venus',
    'music/game/creative/creative1': 'music/game/creative/biome_fest',
    'music/game/creative/creative2': 'music/game/creative/blind_spots',
    'music/game/creative/creative3': 'music/game/creative/haunt_muskie',
    'music/game/creative/creative4': 'music/game/creative/aria_math',
    'music/game/creative/creative5': 'music/game/creative/dreiton',
    'music/game/creative/creative6': 'music/game/creative/taswell',
    'music/game/nether/nether1': 'music/game/nether/concrete_halls',
    'music/game/nether/nether2': 'music/game/nether/dead_voxel',
    'music/game/nether/nether3': 'music/game/nether/warmth',
    'music/game/nether/nether4': 'music/game/nether/ballad_of_the_cats',
    'music/game/end/end': 'music/game/end/the_end',
    'music/game/end/credits': 'music/game/end/alpha'
}

def replace_multiple(text: str, replacements: dict[str, str]) -> str:
    for old, new in replacements.items():
        text = text.replace(old, new)
    return text

def pack_overlay_version(overlay_folder: str):
    copy_file = "./assets/minecraft/sounds.json"
    updated_file = "./" + overlay_folder + '/' + copy_file

    print('Updating "' + copy_file + '" in overlay "' + overlay_folder + '"')

    with open(copy_file, 'r') as file:
        lines = file.readlines()

    updated_lines = [replace_multiple(line, replacements) for line in lines]

    with open(updated_file, 'w') as file:
        file.writelines(updated_lines)

# main
pack_overlay_version('1.20.3-')
print("Done. (enter any key to exit)")
input()
